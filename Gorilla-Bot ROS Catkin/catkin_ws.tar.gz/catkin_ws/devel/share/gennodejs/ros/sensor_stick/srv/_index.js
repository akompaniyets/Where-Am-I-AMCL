
"use strict";

let GetNormals = require('./GetNormals.js')
let GetFloatArrayFeature = require('./GetFloatArrayFeature.js')

module.exports = {
  GetNormals: GetNormals,
  GetFloatArrayFeature: GetFloatArrayFeature,
};
