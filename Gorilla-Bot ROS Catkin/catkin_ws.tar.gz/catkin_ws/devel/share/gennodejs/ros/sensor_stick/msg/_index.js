
"use strict";

let DetectedObject = require('./DetectedObject.js');
let DetectedObjectsArray = require('./DetectedObjectsArray.js');

module.exports = {
  DetectedObject: DetectedObject,
  DetectedObjectsArray: DetectedObjectsArray,
};
